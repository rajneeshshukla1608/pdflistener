#!C:/python37/python 
print("Content-type:text/html\n\n")
import PyPDF2
from gtts import gTTS
book = open('puzzles.pdf', 'rb')
pdfReador = PyPDF2.PdfFileReader(book)
pages = pdfReador.numPages
print("there are ",pages, "pages in this pdf file")
lang = 'com'
for num in range(0, pages):
    page = pdfReador.getPage(num)
    text = page.extractText()
    a = gTTS(text, lang)
    path = "C:/xampp/htdocs/login system/patials/c"+str(num)+".mp3"
    a.save(path)
print('''<br/><audio id="mp3_play" controls>
<source src="c7.mp3" type="audio/mpeg">
</audio>''')