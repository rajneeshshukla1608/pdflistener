function load(){
     var input = document.getElementById('audio_2')
     var path = input.innerHTML
      document.innerHTML = `<h2>hello</h2>`
}
document.innerHTML = `<h2>hello</h2>`
