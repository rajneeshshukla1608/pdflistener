console.log("hello");

function getInputvalue() {
    const $pass = document.getElementById("password").value;
    const $cpass = document.getElementById("cpassword").value;
    if($pass == $cpass){
        alert("password match found");
    }
    else{
        alert("password mismatch found")
    }
}